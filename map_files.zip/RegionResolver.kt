package com.zvpn.data.map

/**
 * Enterprise Region Resolver providing full ISO-3166 country code mapping to major geographical regions.
 */
object RegionResolver {
    private val AMERICAS = setOf(
        "US", "CA", "MX", "BR", "AR", "CL", "CO", "PE", "VE", "EC", "GT", "CU", "CR", "PA",
        "UY", "BO", "PY", "HN", "SV", "NI", "DO", "HT", "JM", "PR", "BS", "BZ", "GY", "SR",
        "TT", "BB", "GD", "LC", "VC", "AG", "KN", "DM"
    )

    private val EUROPE = setOf(
        "DE", "FR", "GB", "UK", "NL", "IT", "ES", "PL", "SE", "FI", "CH", "AT", "NO", "DK", "BE",
        "CZ", "RO", "UA", "RU", "GR", "IE", "PT", "HU", "BG", "SK", "HR", "RS", "LT", "SI",
        "LV", "EE", "BA", "AL", "MK", "LU", "MT", "IS", "MD", "ME", "CY", "BY", "AD", "SM",
        "MC", "LI", "VA"
    )

    private val ASIA_PACIFIC = setOf(
        "JP", "KR", "SG", "HK", "TW", "IN", "AU", "NZ", "ID", "TH", "MY", "PH", "VN", "PK",
        "BD", "KH", "LK", "MM", "NP", "LA", "MN", "BN", "MV", "BT", "FJ", "PG", "SB", "VU",
        "NC", "PF", "WS", "TO", "KI", "FM", "PW", "MH", "TV", "NR"
    )

    private val ME_AFRICA = setOf(
        "AE", "SA", "EG", "TR", "IL", "QA", "BH", "KW", "OM", "ZA", "MA", "DZ", "TN", "NG",
        "KE", "GH", "ET", "TZ", "UG", "CI", "CM", "SN", "ZM", "ZW", "AO", "MZ", "MU", "JO", "LB", "IQ",
        "SD", "LY", "SY", "YE", "RW", "BI", "MW", "SL", "LR", "MR", "ER", "SO", "DJ", "GM", "GW", "GN"
    )

    fun resolve(cc: String?): String {
        val code = cc?.uppercase()?.trim() ?: return "Other"
        return when {
            code in AMERICAS -> "Americas"
            code in EUROPE -> "Europe"
            code in ASIA_PACIFIC -> "Asia-Pacific"
            code in ME_AFRICA -> "ME/Africa"
            else -> "Other"
        }
    }
}
