package com.zvpn.ui.map

import com.zvpn.domain.config.VpnProfile

enum class ProtocolFilter(val id: String, val label: String) {
    All("all", "All"),
    OpenVPN("openvpn", "OpenVPN"),
    VLESS("vless", "VLESS"),
    VMess("vmess", "VMess"),
    Shadowsocks("shadowsocks", "Shadowsocks"),
    WireGuard("wireguard", "WireGuard"),
    Trojan("trojan", "Trojan"),
    Hysteria2("hysteria2", "Hysteria2");

    companion object {
        fun fromId(id: String): ProtocolFilter = entries.find { it.id.equals(id, true) } ?: All
    }
}

enum class RegionFilter(val id: String, val label: String) {
    All("all", "All Regions"),
    Americas("americas", "Americas"),
    Europe("europe", "Europe"),
    AsiaPacific("asia_pacific", "Asia-Pacific"),
    MeAfrica("me_africa", "ME/Africa");

    companion object {
        fun fromId(id: String): RegionFilter = entries.find { it.id.equals(id, true) } ?: All
    }
}

enum class PingFilter(val id: String, val label: String, val maxMs: Int?) {
    All("all", "Any Ping", null),
    Lt100("lt_100", "< 100 ms", 100),
    Lt200("lt_200", "< 200 ms", 200),
    Lt300("lt_300", "< 300 ms", 300);

    companion object {
        fun fromId(id: String): PingFilter = entries.find { it.id.equals(id, true) } ?: All
    }
}

data class MapUiState(
    val searchQuery: String = "",
    val protocolFilter: ProtocolFilter = ProtocolFilter.All,
    val regionFilter: RegionFilter = RegionFilter.All,
    val pingFilter: PingFilter = PingFilter.All,
    val filteredProfiles: List<VpnProfile> = emptyList(),
    val selectedServer: VpnProfile? = null,
    val activeProfileId: String? = null,
    val pingingIds: Set<String> = emptySet(),
    val totalCount: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
) {
    val hasActiveFilters: Boolean
        get() = searchQuery.isNotBlank() ||
                protocolFilter != ProtocolFilter.All ||
                regionFilter != RegionFilter.All ||
                pingFilter != PingFilter.All

    val isEmpty: Boolean
        get() = filteredProfiles.isEmpty()
}
