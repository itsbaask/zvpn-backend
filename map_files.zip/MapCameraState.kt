package com.zvpn.ui.map

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import kotlin.math.min

/**
 * Manages map viewport transformation, scaling, panning, framing, and camera animations.
 */
@Stable
class MapCameraState(
    initialScale: Float = 1f,
    initialOffset: Offset = Offset.Zero,
    private val reduceMotion: Boolean = false
) {
    val scaleAnim = Animatable(initialScale)
    val offsetXAnim = Animatable(initialOffset.x)
    val offsetYAnim = Animatable(initialOffset.y)

    var canvasSize: Size = Size.Zero

    val viewport: MapViewport
        get() = MapViewport(scaleAnim.value, Offset(offsetXAnim.value, offsetYAnim.value))

    suspend fun animateTo(point: MapPoint, targetScale: Float = 4f, durationMs: Int = 450) {
        if (canvasSize.width <= 0f || canvasSize.height <= 0f) return
        val cx = canvasSize.width / 2f
        val cy = canvasSize.height / 2f
        val targetX = cx - point.x * targetScale
        val targetY = cy - point.y * targetScale
        val clamped = clampOffset(Offset(targetX, targetY), targetScale, canvasSize)

        val spec = if (reduceMotion) tween(0) else spring<Float>(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioNoBouncy)

        scaleAnim.animateTo(targetScale, spec)
        offsetXAnim.animateTo(clamped.x, spec)
        offsetYAnim.animateTo(clamped.y, spec)
    }

    suspend fun zoomBy(factor: Float, centroid: Offset = Offset.Zero) {
        val currentScale = scaleAnim.value
        val floor = wholeWorldScale(canvasSize)
        val nextScale = (currentScale * factor).coerceIn(floor, floor * 24f)
        val currentOffset = Offset(offsetXAnim.value, offsetYAnim.value)
        val applied = if (currentScale == 0f) 1f else nextScale / currentScale
        val anchored = if (centroid == Offset.Zero) {
            Offset(canvasSize.width / 2f, canvasSize.height / 2f) - (Offset(canvasSize.width / 2f, canvasSize.height / 2f) - currentOffset) * applied
        } else {
            centroid - (centroid - currentOffset) * applied
        }
        val clamped = clampOffset(anchored, nextScale, canvasSize)

        if (reduceMotion) {
            scaleAnim.snapTo(nextScale)
            offsetXAnim.snapTo(clamped.x)
            offsetYAnim.snapTo(clamped.y)
        } else {
            scaleAnim.animateTo(nextScale, tween(150))
            offsetXAnim.animateTo(clamped.x, tween(150))
            offsetYAnim.animateTo(clamped.y, tween(150))
        }
    }

    suspend fun recenter(durationMs: Int = 400) {
        if (canvasSize.width <= 0f || canvasSize.height <= 0f) return
        val floor = wholeWorldScale(canvasSize)
        val targetOffset = Offset((canvasSize.width - com.zvpn.data.map.WorldMap.WIDTH * floor) / 2f, (canvasSize.height - com.zvpn.data.map.WorldMap.HEIGHT * floor) / 2f)
        val spec = if (reduceMotion) tween(0) else spring<Float>(stiffness = Spring.StiffnessMedium)

        scaleAnim.animateTo(floor, spec)
        offsetXAnim.animateTo(targetOffset.x, spec)
        offsetYAnim.animateTo(targetOffset.y, spec)
    }

    suspend fun fitTo(points: List<MapPoint>, durationMs: Int = 500) {
        if (points.isEmpty() || canvasSize.width <= 0f || canvasSize.height <= 0f) {
            recenter(durationMs)
            return
        }
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }

        val spanX = maxOf(maxX - minX, 100f)
        val spanY = maxOf(maxY - minY, 100f)
        val scaleX = canvasSize.width / spanX * 0.75f
        val scaleY = canvasSize.height / spanY * 0.75f
        val floor = wholeWorldScale(canvasSize)
        val targetScale = min(scaleX, scaleY).coerceIn(floor, floor * 16f)

        val centerX = (minX + maxX) / 2f
        val centerY = (minY + maxY) / 2f
        val targetX = canvasSize.width / 2f - centerX * targetScale
        val targetY = canvasSize.height / 2f - centerY * targetScale
        val clamped = clampOffset(Offset(targetX, targetY), targetScale, canvasSize)

        val spec = if (reduceMotion) tween(0) else spring<Float>(stiffness = Spring.StiffnessLow)
        scaleAnim.animateTo(targetScale, spec)
        offsetXAnim.animateTo(clamped.x, spec)
        offsetYAnim.animateTo(clamped.y, spec)
    }
}

@Composable
fun rememberMapCameraState(reduceMotion: Boolean = false): MapCameraState {
    return remember(reduceMotion) { MapCameraState(reduceMotion = reduceMotion) }
}
