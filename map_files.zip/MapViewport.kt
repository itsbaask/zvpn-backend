package com.zvpn.ui.map

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.zvpn.data.map.WorldMap
import kotlin.math.max
import kotlin.math.min

data class MapViewport(val scale: Float, val offset: Offset)

fun wholeWorldScale(size: Size): Float =
    if (size.width <= 0f || size.height <= 0f) 1f
    else min(size.width / WorldMap.WIDTH, size.height / WorldMap.HEIGHT)

fun clampOffset(offset: Offset, scale: Float, size: Size): Offset {
    val worldW = WorldMap.WIDTH * scale
    val worldH = WorldMap.HEIGHT * scale
    val minX = min(0f, size.width - worldW)
    val minY = min(0f, size.height - worldH)
    val maxX = max(0f, size.width - worldW)
    val maxY = max(0f, size.height - worldH)
    return Offset(
        offset.x.coerceIn(minX, maxX),
        offset.y.coerceIn(minY, maxY)
    )
}

fun wholeWorldOffset(size: Size, scale: Float): Offset {
    val worldW = WorldMap.WIDTH * scale
    val worldH = WorldMap.HEIGHT * scale
    return Offset((size.width - worldW) / 2f, (size.height - worldH) / 2f)
}

fun framing(size: Size, points: List<MapPoint>): MapViewport {
    if (size.width <= 0f || size.height <= 0f) return MapViewport(1f, Offset.Zero)
    val floor = wholeWorldScale(size)
    if (points.isEmpty()) {
        return MapViewport(floor, wholeWorldOffset(size, floor))
    }
    val minX = points.minOf { it.x }
    val maxX = points.maxOf { it.x }
    val minY = points.minOf { it.y }
    val maxY = points.maxOf { it.y }

    val spanX = maxOf(maxX - minX, 150f)
    val spanY = maxOf(maxY - minY, 150f)
    val scaleX = size.width / spanX * 0.70f
    val scaleY = size.height / spanY * 0.70f
    val scale = min(scaleX, scaleY).coerceIn(floor, floor * 16f)

    val cx = (minX + maxX) / 2f
    val cy = (minY + maxY) / 2f
    val x = size.width / 2f - cx * scale
    val y = size.height / 2f - cy * scale
    return MapViewport(scale, clampOffset(Offset(x, y), scale, size))
}
